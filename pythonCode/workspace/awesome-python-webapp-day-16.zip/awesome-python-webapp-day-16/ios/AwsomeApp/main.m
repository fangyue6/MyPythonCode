//
//  main.m
//  AwsomeApp
//
//  Created by Michael Liao on 6/5/14.
//  Copyright (c) 2014 iTranswarp. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "APAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([APAppDelegate class]));
    }
}
